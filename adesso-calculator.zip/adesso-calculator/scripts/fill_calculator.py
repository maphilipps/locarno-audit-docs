#!/usr/bin/env python3
"""
Befüllt den adesso Calculator mit Features, Tasks und Risiken.
Erhält VBA-Makros und Formeln durch direkte XML-Manipulation.
"""

import zipfile
import json
import sys
from pathlib import Path
from lxml import etree

NS = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

# Aufwands-Verhältnisse (aus Forecasted percentages)
R_PCT, S_PCT, T_PCT, U_PCT = 0.25, 0.50, 0.15, 0.10

# Task-ID zu Zeile Mapping
TASK_ROW_MAP = {
    "P-10": 13, "P-20": 14, "P-30": 15, "P-40": 16, "P-50": 17,
    "P-90": 21, "P-100": 22, "P-110": 23, "P-120": 24, "P-130": 25,
    "P-150": 27, "P-160": 28, "P-170": 29, "P-180": 30, "P-190": 31,
    "P-200": 32, "P-210": 33, "P-220": 34, "P-230": 35, "P-250": 37,
}

# Tasks mit Formeln - NICHT überschreiben
FORMULA_TASKS = {"P-60", "P-70", "P-80", "P-140", "P-240"}


def calc_efforts(s_value):
    """Berechnet R, T, U aus S basierend auf den Forecasted percentages."""
    return (
        round(s_value * (R_PCT / S_PCT)),
        s_value,
        round(s_value * (T_PCT / S_PCT)),
        round(s_value * (U_PCT / S_PCT))
    )


def set_cell(row, col_letter, row_num, value, is_number=False):
    """Setzt oder aktualisiert eine Zelle in der XML-Struktur."""
    cell_ref = f'{col_letter}{row_num}'
    cell = row.find(f".//main:c[@r='{cell_ref}']", NS)
    
    if cell is None:
        cell = etree.SubElement(row, '{%s}c' % NS['main'])
        cell.set('r', cell_ref)
    
    for elem in list(cell):
        cell.remove(elem)
    
    if is_number:
        if 't' in cell.attrib:
            del cell.attrib['t']
        v_elem = etree.SubElement(cell, '{%s}v' % NS['main'])
        v_elem.text = str(value)
    else:
        cell.set('t', 'inlineStr')
        is_elem = etree.SubElement(cell, '{%s}is' % NS['main'])
        t_elem = etree.SubElement(is_elem, '{%s}t' % NS['main'])
        t_elem.text = str(value)


def fill_calculator(template_path, output_path, data):
    """
    Befüllt das Calculator-Template mit den übergebenen Daten.
    
    Args:
        template_path: Pfad zum Template XLSM
        output_path: Pfad für die Ausgabedatei
        data: Dictionary mit features, tasks, risks
    """
    features = data.get('features', [])
    tasks = data.get('tasks', {})
    risks = data.get('risks', [])
    
    # Sammle Risiko-Verknüpfungen
    feature_risks = {}  # {row_num: [risk_ids]}
    task_risks = {}     # {row_num: [risk_ids]}
    
    for risk in risks:
        linked_to = risk.get('linked_to', '')
        if linked_to.startswith('F-'):
            num = int(linked_to.split('-')[1])
            row = 10 + (num // 10)
            feature_risks.setdefault(row, []).append(risk['id'])
        elif linked_to.startswith('P-'):
            row = TASK_ROW_MAP.get(linked_to)
            if row:
                task_risks.setdefault(row, []).append(risk['id'])
    
    with zipfile.ZipFile(template_path, 'r') as zin:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                xml_data = zin.read(item.filename)
                
                # Features (sheet2.xml)
                if item.filename == 'xl/worksheets/sheet2.xml':
                    root = etree.fromstring(xml_data)
                    sheet_data = root.find('.//main:sheetData', NS)
                    
                    for i, feat in enumerate(features):
                        row_num = 11 + i
                        if row_num >= 100:
                            break
                            
                        row = sheet_data.find(f".//main:row[@r='{row_num}']", NS)
                        if row is None:
                            continue
                        
                        r, s, t, u = calc_efforts(feat['effort'])
                        
                        set_cell(row, 'A', row_num, feat['id'])
                        set_cell(row, 'C', row_num, feat.get('group', ''))
                        set_cell(row, 'E', row_num, feat['title'])
                        set_cell(row, 'G', row_num, feat.get('description', ''))
                        if feat.get('assumptions'):
                            set_cell(row, 'H', row_num, feat['assumptions'])
                        if row_num in feature_risks:
                            set_cell(row, 'I', row_num, ', '.join(feature_risks[row_num]))
                        set_cell(row, 'R', row_num, r, is_number=True)
                        set_cell(row, 'S', row_num, s, is_number=True)
                        set_cell(row, 'T', row_num, t, is_number=True)
                        set_cell(row, 'U', row_num, u, is_number=True)
                    
                    xml_data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone='yes')
                
                # Project tasks (sheet3.xml)
                elif item.filename == 'xl/worksheets/sheet3.xml':
                    root = etree.fromstring(xml_data)
                    sheet_data = root.find('.//main:sheetData', NS)
                    
                    for task_id, effort in tasks.items():
                        if task_id in FORMULA_TASKS:
                            continue
                        row_num = TASK_ROW_MAP.get(task_id)
                        if not row_num:
                            continue
                        
                        row = sheet_data.find(f".//main:row[@r='{row_num}']", NS)
                        if row is not None:
                            set_cell(row, 'J', row_num, effort, is_number=True)
                    
                    # Risiko-Verknüpfungen in Spalte H
                    for row_num, risk_ids in task_risks.items():
                        row = sheet_data.find(f".//main:row[@r='{row_num}']", NS)
                        if row is not None:
                            set_cell(row, 'H', row_num, ', '.join(risk_ids))
                    
                    xml_data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone='yes')
                
                # Project risks (sheet5.xml)
                elif item.filename == 'xl/worksheets/sheet5.xml':
                    root = etree.fromstring(xml_data)
                    sheet_data = root.find('.//main:sheetData', NS)
                    
                    for i, risk in enumerate(risks):
                        row_num = 8 + i
                        
                        row = sheet_data.find(f".//main:row[@r='{row_num}']", NS)
                        if row is None:
                            row = etree.SubElement(sheet_data, '{%s}row' % NS['main'])
                            row.set('r', str(row_num))
                        
                        set_cell(row, 'A', row_num, risk['id'])
                        set_cell(row, 'B', row_num, risk['title'])
                        set_cell(row, 'C', row_num, risk.get('description', ''))
                        set_cell(row, 'E', row_num, risk['likelihood'], is_number=True)
                        set_cell(row, 'F', row_num, risk['impact'], is_number=True)
                    
                    xml_data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone='yes')
                
                zout.writestr(item, xml_data)
    
    return output_path


if __name__ == '__main__':
    if len(sys.argv) < 4:
        print("Usage: fill_calculator.py <template.xlsm> <output.xlsm> <data.json>")
        sys.exit(1)
    
    template = sys.argv[1]
    output = sys.argv[2]
    data_file = sys.argv[3]
    
    with open(data_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    fill_calculator(template, output, data)
    print(f"Calculator befüllt: {output}")
