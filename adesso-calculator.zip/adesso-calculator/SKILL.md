---
name: adesso-calculator
description: >
  Befüllt den adesso Projektkalkulator (XLSM) mit Features, Aufwänden, Risiken und Task-Schätzungen.
  Verwende diesen Skill wenn der Benutzer eine Projektkalkulation erstellen möchte, Features und
  Aufwände schätzen will, oder den adesso Calculator befüllen möchte. Trigger-Phrasen sind
  Kalkulation erstellen, adesso Calculator, Projektkalkulation, Features schätzen, Aufwände kalkulieren.
---

# adesso-calculator

Befüllt den adesso Projektkalkulator mit Projektdaten unter Erhalt aller VBA-Makros und Formeln.

## Template

Das Template liegt unter `assets/template.xlsm` und muss für jede Kalkulation kopiert werden.

## Zu befüllende Daten

### 1. Features (Blatt "Features", ab Zeile 11, max. bis Zeile 99)

| Spalte | Feld | Pflicht | Beschreibung |
|--------|------|---------|--------------|
| A | ID | Ja | F-10, F-20, F-30, ... (Zehnerschritte) |
| C | Feature Group | Ja | Gruppierung (z.B. "Frontend", "Backend", "Integration") |
| E | Feature Title | Ja | Kurzer Titel des Features |
| G | Feature Description | Ja | Ausführliche Beschreibung |
| H | Assumptions | Nein | Annahmen für das Feature |
| I | Risk IDs | Nein | Verknüpfte Risiko-IDs (z.B. "R-10, R-20") |
| R | Analyse & Design | Ja | Aufwand in PT (berechnet aus S × 0.5) |
| S | Softwareentwicklung | Ja | Hauptaufwand in PT (Basis für Berechnung) |
| T | Softwaretest | Ja | Aufwand in PT (berechnet aus S × 0.3) |
| U | Fehlerbearb. nach BzA | Ja | Aufwand in PT (berechnet aus S × 0.2) |

**Aufwandsberechnung:** Spalte S ist der Basiswert. R, T, U werden proportional berechnet:
- R = S × (0.25 / 0.50) = S × 0.5
- T = S × (0.15 / 0.50) = S × 0.3  
- U = S × (0.10 / 0.50) = S × 0.2

### 2. Project Tasks (Blatt "Project tasks", Spalte J)

Nur Tasks OHNE Formel erhalten manuelle Schätzungen:

| Task-ID | Task | Schätzung in J |
|---------|------|----------------|
| P-10 | Projektinitialisierung und -planung | Manuell |
| P-20 | Planung und Durchführung Projekt Kick Off | Manuell |
| P-30 | Erstellung Software Architekturkonzept | Manuell |
| P-40 | Erstellung Testkonzept | Manuell |
| P-50 | Aufbau Entwicklungsumgebung | Manuell |
| P-90 | Entwicklung und Wartung Testautomatisierung | Manuell |
| P-100 | Performance Test | Manuell |
| P-110 | Sicherheitsprüfung | Manuell |
| P-120 | Erstellung Anwenderhandbuch | Manuell |
| P-130 | Kundenschulung | Manuell |
| P-150 | Datenmigration | Manuell |
| P-160 | Unterstützung bei Installation | Manuell |
| P-170 | Projektmanagement | Manuell |
| P-180 | Testmanagement | Manuell |
| P-190 | Architekturmanagement | Manuell |
| P-200 | DevOps Support | Manuell |
| P-210 | Smartshoremanagement | Manuell |
| P-220 | Projektmeetings | Manuell |
| P-230 | Reisezeiten | Manuell |
| P-250 | Gewährleistung | Manuell |

**NICHT befüllen** (haben Formeln):
- P-60 (Analyse & Software Design) → `=Features!R9`
- P-70 (Software-entwicklung) → `=Features!S9`
- P-80 (Softwaretest) → `=Features!T9`
- P-140 (Fehlerbearb. nach BzA) → `=Features!U9`
- P-240 (Risiken) → `=RI_WeightedImpact`

Task-Risiko-Verknüpfungen werden in **Spalte H** eingetragen.

### 3. Project Risks (Blatt "Project risks", ab Zeile 8)

| Spalte | Feld | Beschreibung |
|--------|------|--------------|
| A | ID | R-10, R-20, R-30, ... (Zehnerschritte) |
| B | Risk Title | Kurzer Titel |
| C | Risk Description | Ausführliche Beschreibung |
| E | Likelihood | Wahrscheinlichkeit (0.0 - 1.0) |
| F | Impact | Auswirkung in Tagen |
| G | *Automatisch* | Formel `=IFERROR(E*F,0)` |

## Technische Umsetzung

Das XLSM als ZIP behandeln und nur die XML-Dateien der Worksheets modifizieren:
- `xl/worksheets/sheet2.xml` → Features
- `xl/worksheets/sheet3.xml` → Project tasks  
- `xl/worksheets/sheet5.xml` → Project risks

**Wichtig:** 
- `keep_vba=True` beim Laden mit openpyxl (nur zum Lesen/Verifizieren)
- Für Schreiboperationen: Direkte XML-Manipulation mit lxml
- Strings als `inlineStr` mit `<is><t>...</t></is>`
- Zahlen ohne type-Attribut mit `<v>...</v>`

## Beispiel-Script

Siehe `scripts/fill_calculator.py` für die vollständige Implementierung.
